# Greetings

Description.
    The package greeting is used as a pratice named "desafio de projeto" on DIO course platform.

## Installation

Use the package manager to install the package

```bash
pip install greetings
```

## Usage

```python
from greetings.greeting import phrases
phrases.my_function()
```

## Author
Raimundo Azevedo
