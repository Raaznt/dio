#Greetings

The "Greetings" package is a package used on DIO's course exercise named "desafio de projeto"

##Installation

To install use the package manager pip as follows:

```bash
pip install greetings
```

##Usage
```python
from greetings.greeting import phrases
phrases.hello()
```
