def hello():
    print("Hello everyone")
